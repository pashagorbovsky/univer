from fake_math import divide as d1
from true_math import divide as d2

result1 = d1(69, 3)
result2 = d1(3, 0)
result3 = d2(49, 7)
result4 = d2(15, 0)

print(result1)
print(result2)
print(result3)
print(result4)